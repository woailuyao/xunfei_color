# Traffic Light Detection

## 介绍
这是一个基于 OpenCV 的红绿灯检测项目，支持视频文件和摄像头的实时检测。

## 功能
- 读取视频文件或摄像头画面。
- 检测红绿灯，并实时显示模式（RED, GREEN, NOT）。
- 在画面左上角用蓝色字体标注当前模式。

## 环境
- OpenCV 4.10
- C++17
- CMake 3.10+

## 使用方法
1. 构建项目：
   ```bash
   mkdir build && cd build
   cmake ..
   make
