#include <opencv2/opencv.hpp>
#include <iostream>

// HSV 范围结构
struct ColorRange {
    cv::Scalar lower;
    cv::Scalar upper;
};

// 定义红绿灯 HSV 范围
const ColorRange RED1 = {cv::Scalar(0, 120, 150), cv::Scalar(10, 255, 255)};
const ColorRange RED2 = {cv::Scalar(160, 120, 150), cv::Scalar(180, 255, 255)};
const ColorRange GREEN = {cv::Scalar(40, 50, 110), cv::Scalar(90, 255, 255)};

// 红绿灯检测函数
std::string detectTrafficLight(const cv::Mat& frame, cv::Rect& detectedBox) {
    // 转换为 HSV 色彩空间
    cv::Mat hsv;
    cv::cvtColor(frame, hsv, cv::COLOR_BGR2HSV);

    // 红灯检测
    cv::Mat redMask1, redMask2, redMask;
    cv::inRange(hsv, RED1.lower, RED1.upper, redMask1);
    cv::inRange(hsv, RED2.lower, RED2.upper, redMask2);
    redMask = redMask1 | redMask2;

    // 绿灯检测
    cv::Mat greenMask;
    cv::inRange(hsv, GREEN.lower, GREEN.upper, greenMask);

    // 对掩码进行形态学操作去噪
    cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(5, 5));
    cv::morphologyEx(redMask, redMask, cv::MORPH_CLOSE, kernel);
    cv::morphologyEx(greenMask, greenMask, cv::MORPH_CLOSE, kernel);

    // 轮廓检测
    std::vector<std::vector<cv::Point>> redContours, greenContours;
    cv::findContours(redMask, redContours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    cv::findContours(greenMask, greenContours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    // 找到最大的轮廓并绘制识别框
    double maxRedArea = 0, maxGreenArea = 0;
    cv::Rect redBox, greenBox;

    for (const auto& contour : redContours) {
        double area = cv::contourArea(contour);
        if (area > maxRedArea) {
            maxRedArea = area;
            redBox = cv::boundingRect(contour);
        }
    }

    for (const auto& contour : greenContours) {
        double area = cv::contourArea(contour);
        if (area > maxGreenArea) {
            maxGreenArea = area;
            greenBox = cv::boundingRect(contour);
        }
    }

    // 根据面积大小确定最终模式
    if (maxRedArea > maxGreenArea && maxRedArea > 1000) {
        detectedBox = redBox;
        return "RED";
    } else if (maxGreenArea > maxRedArea && maxGreenArea > 1000) {
        detectedBox = greenBox;
        return "GREEN";
    } else {
        detectedBox = cv::Rect(); // 未检测到
        return "NOT";
    }
}

// 视频处理函数
void processVideo(const std::string& videoPath) {
    cv::VideoCapture cap(videoPath);
    if (!cap.isOpened()) {
        std::cerr << "Unable to open video file: " << videoPath << std::endl;
        return;
    }

    cv::Mat frame;
    while (true) {
        cap >> frame;
        if (frame.empty()) break;

        // 检测红绿灯模式
        cv::Rect detectedBox;
        std::string mode = detectTrafficLight(frame, detectedBox);

        // 显示模式标注
        cv::putText(frame, mode, cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(255, 0, 0), 2);

        // 绘制识别框并显示面积
        if (!detectedBox.empty()) {
            cv::rectangle(frame, detectedBox, cv::Scalar(0, 255, 0), 2); // 绿色框

            // 计算面积并显示
            int area = detectedBox.width * detectedBox.height;
            std::string areaText = "Area: " + std::to_string(area);
            cv::Point textPosition(detectedBox.x, detectedBox.y - 10); // 框上方
            cv::putText(frame, areaText, textPosition, cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 255, 0), 2);
        }

        // 显示结果
        cv::imshow("Traffic Light Detection", frame);
        if (cv::waitKey(30) >= 0) break;
    }
}

// 摄像头实时处理函数
void processCamera() {
    cv::VideoCapture cap(0); // 打开默认摄像头
    if (!cap.isOpened()) {
        std::cerr << "Unable to open the camera" << std::endl;
        return;
    }

    cv::Mat frame;
    while (true) {
        cap >> frame; // 获取摄像头画面
        if (frame.empty()) break;

        // 检测红绿灯模式
        cv::Rect detectedBox;
        std::string mode = detectTrafficLight(frame, detectedBox);

        // 显示模式标注
        cv::putText(frame, mode, cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(255, 0, 0), 2);

        // 绘制识别框并显示面积
        if (!detectedBox.empty()) {
            cv::rectangle(frame, detectedBox, cv::Scalar(0, 255, 0), 2); // 绿色框

            // 计算面积并显示
            int area = detectedBox.width * detectedBox.height;
            std::string areaText = "Area: " + std::to_string(area);
            cv::Point textPosition(detectedBox.x, detectedBox.y - 10); // 框上方
            cv::putText(frame, areaText, textPosition, cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 255, 0), 2);
        }

        // 显示结果
        cv::imshow("Camera Feed", frame);
        if (cv::waitKey(30) >= 0) break;
    }
}

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <video_path | camera>" << std::endl;
        return -1;
    }

    std::string input = argv[1];
    if (input == "camera") {
        processCamera(); // 处理摄像头
    } else {
        processVideo(input); // 处理视频文件
    }

    return 0;
}
